import{w as i}from"./index.DGw2-XJO.js";const a=i(!1);export{a as i};
