import{b as a}from"../chunks/entry.Cwgp6uEs.js";export{a as start};
